# Mawqid Restaurants: Sample Company Data

**Fictional company, generated data.** Mawqid is an invented restaurant chain with 10 branches in Saudi Arabia.
Every number here is synthetic and was generated with a fixed seed. Delivery app names (HungerStation, Jahez,
Keeta, ToYou) are used as labels only; their figures say nothing about those companies.

- Period: 1 Jan 2025 to 31 Oct 2026
- Currency: SAR. Sales amounts in POS and delivery-app files **include 15% VAT**. Finance (GL, budget),
  purchases and payroll amounts **exclude VAT**.
- Each folder is an export from a different system, so formats, codes and naming differ between folders
  on purpose. Part of the work is to make them talk to each other.

## 00_HQ

| File | Grain | Notes |
|---|---|---|
| `branches.xlsx` | 1 row per branch | Master list. Links the POS code (`BranchCode`), finance cost center (`CostCenter`) and HR location (`HRLocationCode`). Branch B06 opened on 15 Sep 2025. |
| `calendar_events.csv` | 1 row per event | Ramadan, Eids, national days, school summer break (approximate dates). |

## 01_POS (point of sale)

| File | Grain | Notes |
|---|---|---|
| `hourly_sales/pos_hourly_YYYY-MM.csv` | business date x branch x hour x channel | One file per month. `BusinessDate` is the trading day: hours 0 to 3 belong to the night of the previous calendar day. `Guests` only for dine-in. `PaidApp` = settled by the delivery app. |
| `pos_item_sales_monthly.csv` | month x branch x channel group x item | Item mix. Channel group is Dine-in, Takeaway, Drive-thru or Delivery (all apps). |
| `menu_items.csv` | 1 row per item | 34 items in 6 categories. |
| `menu_prices.csv` | item x price period | Prices incl. VAT, with `ValidFrom` / `ValidTo`. |

## 02_Delivery_Apps

Daily settlement reports, one row per date x branch, in each app's own format:
`hungerstation_settlements.csv`, `jahez_settlements.xlsx` (Arabic headers), `keeta_settlements.csv`,
`toyou_settlements.csv`. Order value = menu value incl. VAT. "Restaurant / merchant / vendor discount" is
funded by Mawqid; the app-funded discount is not a Mawqid cost. Commission is charged on order value after the
restaurant discount. Payout = order value - restaurant discount - commission. Cancelled orders are not in POS.

## 03_Inventory

| File | Grain | Notes |
|---|---|---|
| `ingredients.csv` | 1 row per ingredient | Stock unit, purchase unit and conversion. |
| `suppliers.csv` | 1 row per supplier | |
| `recipes.csv` | item x ingredient | Standard quantity of each ingredient per item sold (stock unit). |
| `purchases.csv` | invoice line | Supplier invoices received at each branch, ex VAT plus VAT. |
| `stock_counts.csv` | count date x branch x ingredient | Month-end physical counts; 31 Dec 2024 is the opening count. |
| `waste_log.csv` | waste entry | Recorded waste with reason and the employee who recorded it. |

## 04_HR

| File | Grain | Notes |
|---|---|---|
| `employees.xlsx` | 1 row per employee | Everyone employed at any time in the period, including leavers. |
| `timesheets.csv` | employee x working day | Status, shift times, scheduled, worked and overtime hours. Weekly days off have no row. |
| `payroll.csv` | employee x month | Monthly cost; `TotalEmployerCost` includes the employer GOSI share. |

## 05_Customer_Feedback

`feedback.csv`: one row per review, survey response or call-center complaint, with a 1 to 5 rating and a
complaint category when the customer complained.

## 06_Finance

| File | Grain | Notes |
|---|---|---|
| `general_ledger.xlsx` | period x cost center x account | One sheet per year. Revenue is posted as credit, costs as debit. `CC900` is head office. |
| `chart_of_accounts.csv` | 1 row per account | Account type, P&L group and sort order. |
| `budget.xlsx` | cost center x account, months as columns | One sheet per year. |

## Known data quality issues

Real exports are not clean, and neither are these. Expect to handle differences in branch naming between
systems, date formats, numbers stored as text, units, column changes over time, duplicates, inconsistent text
values and at least one gap between two systems that should agree.
